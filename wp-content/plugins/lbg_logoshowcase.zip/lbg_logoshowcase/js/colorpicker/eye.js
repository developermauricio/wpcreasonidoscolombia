/**
 *
 * Zoomimage
 * Author: Stefan Petre www.eyecon.ro
 *
 */
(function(d){var e=window.EYE=function(){var c={init:[]};return{init:function(){d.each(c.init,function(b,a){a.call()})},extend:function(b){for(var a in b)void 0!=b[a]&&(this[a]=b[a])},register:function(b,a){c[a]||(c[a]=[]);c[a].push(b)}}}();d(e.init)})(jQuery);
